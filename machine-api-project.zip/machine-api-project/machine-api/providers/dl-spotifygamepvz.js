/**
 * sssspotify
 * base: https://gamepvz.com
 * Note: cek https://snippet.vyr.my.id/shanmolvyr/sssspotify/README.md
 * Sumber: https://whatsapp.com/channel/0029VbB4Kw8EFeXfeExaXc3Q
 */
const url = process.argv[2]

async function getSpotify(spotifyUrl) {
  const res = await fetch("https://gamepvz.com/api/download/get-url", {
    method: "POST",
    headers: { "Content-Type": "application/json", "Accept": "application/json" },
    body: JSON.stringify({ url: spotifyUrl })
  })
  const data = await res.json()
  if (data.code !== 200) throw new Error(data.message || "Failed")

  const downloadUrl = "https://gamepvz.com" + data.originalVideoUrl
  const b64 = new URLSearchParams(data.originalVideoUrl.split("?")[1]).get("url")
  const directUrl = Buffer.from(b64, "base64").toString("utf8")

  return {
    title: data.title,
    artist: data.authorName,
    cover: data.coverUrl,
    download: directUrl
  }
}

module.exports = { getSpotify };
